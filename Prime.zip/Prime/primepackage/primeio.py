#primeio.py

'''Reads and writes the prime numbers found in the csv file.
 
Example:
    python generate.py inputFile outputFile
 
'''
 
__author__ = "Jason Dania"
__license__ = "GPL"
__version__ = "0.1"
__email__ = "jmdania@valdosta.edu"
__status__ = "Prototype"
 
import sys, os # import built-in modules
import bs4 # import third-party modules
import m2 # import own modules
 
def convertRead(filename):
    '''Summary line.
 
    Extended description.
 
    Args:
        filename (str): intput file name.
 
    Returns:
        list: a list of strings.
 
    Raises:
        IOError: io error.
 
    Examples:
        >>> l = convertRead('readme.txt');
 
    '''
    pass
 
def main():
    pass
 
if __name__ == '__main__':
    main()


def write_primes(l, file_name):
   file = open(file_name,'w')
   l = [str(i) for i in l]
   l = ','.join(l)
   file.write(l)
  
def read_primes(file_name):
   file = open(file_name)
   line = file.readline()
   line = [int(i) for i in line.strip().split(',')]
   return line
