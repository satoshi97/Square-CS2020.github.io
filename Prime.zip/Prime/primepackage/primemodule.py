#primemodule.py
'''Determines whether number in list is prime and then prints out all prime numbers in the list.
 
Example:
    python generate.py inputFile outputFile
 
'''
 
__author__ = "Jason Dania"
__license__ = "GPL"
__version__ = "0.1"
__email__ = "jmdania@valdosta.edu"
__status__ = "Prototype"
 
def convertRead(filename):
    '''Summary line.
 
    Extended description.
 
    Args:
        filename (str): input file name.
 
    Returns:
        list: a list of strings.
 
    Raises:
        IOError: io error.
 
    Examples:
        >>> l = convertRead('readme.txt');
 
    '''
    pass
 
def main():
    pass
 
if __name__ == '__main__':
    main()

import math

def isPrime(n):

    if (n == 1):
        return False
    else if (n == 2):
        return True;
    else:
      for i in range(2, int(math.sqrt(n) + 1):
        if (n % x == 0):
           return False
    return True

def getNPrime(num):
   listprime = []
   num1 = 1
   while len(prime_list) < num:
       if isPrime(num1)
           return True
           prime_list.append(num1)
       num1 += 1
   print(listpirme)
   return len(listprime)
getNPrime(100)
    
