#__init__.py

 
__author__ = "Jason Dania"
__license__ = "GPL"
__version__ = "0.1"
__email__ = "jmdania@valdosta.edu"
__status__ = "Prototype"
 
 
def main():
    pass
 
if __name__ == '__main__':
    main()

import  primepackage
primepackage.primemodule.isPrime()

import primepackage.primemodule.isPrime()

from primepackage import isPrime
primemodule.isPrime()

from primepackage import getNPrime
primemodule.getNPrime()

from primepackage.isPrime import isPrime
isPrime()

from primepackage.getNPrime import getNPrime
getNPrime()

import primepackage.primeio.write_primes()

from primepackage import write_primes
write_primes()

from primepackage import read_primes
read_primes()

__all__ = ['isPrime', 'getNPrime', 'write_primes', 'read_primes']

from primepackage.primeio import write_primes, read_primes
from primepackage.primemodule import isPrime, getNPrime


